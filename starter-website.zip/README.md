# Beginner website starter
For a new personal user site (not for overwriting an existing website).
1. Replace YOUR-USERNAME in _config.yml with your GitHub username. Change the site title, description and index.html biography.
2. Create a public repository named YOUR-USERNAME.github.io. Upload the extracted contents including .pages.yml and folders (GitHub Desktop can help).
3. Settings > Pages > Deploy from a branch > main > / (root). Do not add .nojekyll.
4. Check your homepage, /Tech/, /Tech/first-blog/, /robots.txt and /sitemap.xml. GitHub Pages supports the jekyll-sitemap plugin.
5. Optionally sign into app.pagescms.org, authorize your repository, and open Tech Blog.
6. Verify your website in Google Search Console with the URL-prefix property and submit sitemap.xml.
This starter is a generic example, not a copy of the author's website. It has not been deployed in this environment.
